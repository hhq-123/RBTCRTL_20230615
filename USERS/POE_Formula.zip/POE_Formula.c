#include "POE_Formula.h"

POE_Formula* new_POE_Formula(void)
{
	POE_Formula* pObj = NULL;
	pObj = (POE_Formula*)malloc(sizeof(POE_Formula));
	if (pObj == NULL)
	{
		printf("WARN: POE_Formula initialization failed.\r\n");
		return NULL;
	}
	
	if(E3Mat == NULL)
	{
		E3Mat = new_mat_q15(3, 3);
		mat_q15_modify(E3Mat, 0, 0, 0x7fff);
		mat_q15_modify(E3Mat, 1, 1, 0x7fff);
		mat_q15_modify(E3Mat, 2, 2, 0x7fff);
	}
	
	pObj->axis = new_mat_q15(3, 1);
	pObj->axis_[0] = new_mat_q15(3, 3);
	pObj->axis_[1] = new_mat_q15(3, 3);
	
	pObj->pos = new_mat_q15(3, 1);
	pObj->rotMat = new_mat_q15(3, 3);
	pObj->transMat = new_mat_q15(3, 3);
	
	pObj->tempMat13[0] = new_mat_q15(1, 3);
	pObj->tempMat13[1] = new_mat_q15(1, 3);	
	pObj->tempMat31[0] = new_mat_q15(3, 1);
	pObj->tempMat31[1] = new_mat_q15(3, 1);	
	pObj->tempMat33[0] = new_mat_q15(3, 3);
	pObj->tempMat33[1] = new_mat_q15(3, 3);
	
	return pObj;
}

void delete_POE_Formula(POE_Formula* const pPOEFObj)
{
	
}

arm_matrix_instance_q15* new_mat_q15(uint16_t nRows, uint16_t nColumns)
{
	arm_matrix_instance_q15* pObj = NULL;
	q15_t* pData = NULL;
	
	pObj = (arm_matrix_instance_q15*)malloc(sizeof(arm_matrix_instance_q15));
	pData = (q15_t*)malloc(nRows * nColumns);
	memset(pData, 0, sizeof(q15_t)*nRows * nColumns);
	
	if (pObj == NULL || pData == NULL)
	{
		//printf("WARN: Matrix memory allocation failed.\r\n");
		return NULL;
	}
	
	arm_mat_init_q15(pObj, nRows, nColumns, pData);
	return pObj;
}

void delete_mat_q15(arm_matrix_instance_q15* const pMatObj)
{
	

}

void mat_q15_modify(arm_matrix_instance_q15* const pMatObj, uint16_t nRows, uint16_t nColumns, q15_t value)
{
	E3Mat->pData[nRows * pMatObj->numCols + nColumns] = value;
}

void POE_Formula_init(POE_Formula* const pPOEFObj, q15_t* axis, q15_t* pos, q15_t theta)
{
	q15_t pState[9];
	memcpy(pPOEFObj->axis->pData, axis, 3);
	memcpy(pPOEFObj->pos->pData, pos, 3);
	pPOEFObj->theta = theta;
	
	arm_mat_trans_q15(pPOEFObj->axis, pPOEFObj->tempMat13[0]);
	arm_mat_mult_fast_q15(pPOEFObj->axis, pPOEFObj->tempMat13[0], pPOEFObj->axis_[0], pState);

	arm_mat_vec_mult_q15();
	
}



void POE_Formula_calc(POE_Formula* const pPOEFObj, q15_t theta)
{
	pPOEFObj->theta = theta;
	
	
	
}

void POE_Formula_calc_rotMat(POE_Formula* const pPOEFObj)
{
	q15_t temp;
	temp = arm_cos_q15(pPOEFObj->theta);
	arm_mat_scale_q15(pPOEFObj->tempMat33[0], temp, 0, pPOEFObj->rotMat);
	
	temp = 0x7fff-arm_cos_q15(pPOEFObj->theta);
	arm_mat_scale_q15(pPOEFObj->axis_[0], temp, 0, pPOEFObj->tempMat33[0]);
	arm_mat_add_q15(pPOEFObj->tempMat33[0], pPOEFObj->rotMat, pPOEFObj->rotMat);
	
	temp = arm_sin_q15(pPOEFObj->theta);
	arm_mat_scale_q15(pPOEFObj->axis_[1], temp, 0, pPOEFObj->tempMat33[0]);
	arm_mat_add_q15(pPOEFObj->tempMat33[0], pPOEFObj->rotMat, pPOEFObj->rotMat);
}