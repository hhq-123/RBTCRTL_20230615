/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __POE_FORMULA_H__
#define __POE_FORMULA_H__
/* =================================================================================
File name:       __POE_Formula_H__

===================================================================================*/

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "arm_math.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
typedef struct POE_Formula_ POE_Formula;

typedef void (*POEFfptrInit)(POE_Formula*, float, float, float, float, float);
typedef void (*POEFfptrCalc)(POE_Formula*, q15_t);
typedef void (*POEFfptrSet)(POE_Formula*, q15_t);

arm_matrix_instance_q15* E3Mat = NULL;

struct POE_Formula_
{
	q15_t theta;
	
	arm_matrix_instance_q15* axis;
	arm_matrix_instance_q15* axis_[2];//0: p*pT, 1: p~
	arm_matrix_instance_q15* pos;
	
	arm_matrix_instance_q15* rotMat;
	arm_matrix_instance_q15* transMat;
	
	arm_matrix_instance_q15* tempMat13[2];
	arm_matrix_instance_q15* tempMat31[2];
	arm_matrix_instance_q15* tempMat33[2];
	
	//interface for function
	POEFfptrInit init;
	POEFfptrCalc calc;
	POEFfptrSet set;
};
 
POE_Formula* new_POE_Formula(void);
void delete_POE_Formula(POE_Formula* const pPOEFObj);

arm_matrix_instance_q15* new_mat_q15(uint16_t nRows, uint16_t nColumns);
void delete_mat_q15(arm_matrix_instance_q15* const pMatObj);
void mat_q15_modify(arm_matrix_instance_q15* const pMatObj, uint16_t nRows, uint16_t nColumns, q15_t value);

void POE_Formula_init(POE_Formula* const pPOEFObj, q15_t* axis, q15_t* pos, q15_t theta);
void POE_Formula_calc(POE_Formula* const pPOEFObj, q15_t theta);
void POE_Formula_calc_rotMat(POE_Formula* const pPOEFObj);
void POE_Formula_set(POE_Formula* const pPOEFObj, q15_t value);

#endif